use crate::vga;
use crate::fs::fat16;
use core::cell::UnsafeCell;
use core::arch::asm;

const EDITOR_WIDTH: usize = 80;
// Content rows must fit below title (row 0) and separator (row 1),
// with the status bar on the last visible line (row 24).
// Using 22 ensures content draws on rows 2..23 and status on row 24.
const EDITOR_HEIGHT: usize = 22;  // Leave last line for status

// Content area starts at column 5 (after line numbers)
const CONTENT_COL_OFFSET: usize = 5;
const CONTENT_WIDTH: usize = EDITOR_WIDTH - CONTENT_COL_OFFSET;
const MAX_FILE_SIZE: usize = 8192; // Max 8KB file for editor

pub struct TextEditor {
    content: [u8; MAX_FILE_SIZE],
    size: usize,
    cursor_x: usize,
    cursor_y: usize,
    offset: usize,  // Scroll offset
    filename: [u8; 256],
    filename_len: usize,
    modified: bool,
}

struct EditorCell(UnsafeCell<TextEditor>);
unsafe impl Sync for EditorCell {}

static EDITOR: EditorCell = EditorCell(UnsafeCell::new(TextEditor {
    content: [0u8; MAX_FILE_SIZE],
    size: 0,
    cursor_x: 0,
    cursor_y: 0,
    offset: 0,
    filename: [0u8; 256],
    filename_len: 0,
    modified: false,
}));

impl TextEditor {
    fn new() -> Self {
        TextEditor {
            content: [0u8; MAX_FILE_SIZE],
            size: 0,
            cursor_x: 0,
            cursor_y: 0,
            offset: 0,
            filename: [0u8; 256],
            filename_len: 0,
            modified: false,
        }
    }

    fn load_file(&mut self, filename: &[u8]) {
        // Copy filename
        let len = if filename.len() > 255 { 255 } else { filename.len() };
        for i in 0..len {
            self.filename[i] = filename[i];
        }
        self.filename_len = len;
        self.modified = false;
        
        // For now, just clear - would load from FAT16 in full implementation
        self.size = 0;
        self.cursor_x = 0;
        self.cursor_y = 0;
        self.offset = 0;
    }

    fn draw_editor(&self) {
        // Clear screen with blue background
        vga::clear(0x01);

        // Draw title bar
        vga_print!(0, 0, 0x1F, b"");
        for i in 0..self.filename_len {
            vga::write_char(i as u64, 0, self.filename[i], 0x1F);
        }
        if self.modified {
            vga::write_char(self.filename_len as u64, 0, b'*', 0x1F);
        }
        
        // Draw separator
        for col in 0..80 {
            vga::write_char(col as u64, 1, 0xC4, 0x07);
        }

        // Draw content area with line numbers
        let mut line_num = self.offset / CONTENT_WIDTH;
        let mut pos = self.offset;
        
        for row in 0..EDITOR_HEIGHT {
            let actual_row = (row + 2) as u64;
            
            // Draw line number
            let line_str = if line_num < 10 {
                [b' ', b' ', b' ', (48 + line_num as u8), b' ', 0, 0, 0]
            } else if line_num < 100 {
                [b' ', b' ', (48 + (line_num / 10) as u8), (48 + (line_num % 10) as u8), b' ', 0, 0, 0]
            } else {
                [b' ', (48 + (line_num / 100) as u8), (48 + ((line_num / 10) % 10) as u8), (48 + (line_num % 10) as u8), b' ', 0, 0, 0]
            };
            
            for i in 0..4 {
                vga::write_char(i as u64, actual_row, line_str[i], 0x07);
            }

            // Draw content (start at CONTENT_COL_OFFSET)
            let mut col = CONTENT_COL_OFFSET;
            let mut col_idx = 0usize;
            while col < EDITOR_WIDTH && pos < self.size {
                let ch = self.content[pos];
                if ch == b'\n' {
                    pos += 1;
                    line_num += 1;
                    break;
                }
                vga::write_char(col as u64, actual_row, ch, 0x0F);
                col += 1;
                col_idx += 1;
                if col_idx >= CONTENT_WIDTH { break; }
                pos += 1;
            }
            
            // Fill rest of line with spaces
            while col < EDITOR_WIDTH {
                vga::write_char(col as u64, actual_row, b' ', 0x01);
                col += 1;
            }
        }

        // Draw status bar
        let status_y = (EDITOR_HEIGHT + 2) as u64;
        let status = b"F2:Save  F3:Quit  F4:Save&Quit  Ctrl+Q:Quit";
        vga_print!(0, status_y, 0x70, status);
    }

    fn insert_char(&mut self, ch: u8) {
        if self.size >= MAX_FILE_SIZE - 1 {
            return;  // File full
        }
        let insert_pos = self.offset + self.cursor_y * CONTENT_WIDTH + self.cursor_x;
        let insert_pos = if insert_pos > self.size { self.size } else { insert_pos };
        
        // Shift content right
        for i in (insert_pos..self.size).rev() {
            self.content[i + 1] = self.content[i];
        }
        
        self.content[insert_pos] = ch;
        self.size += 1;
        self.modified = true;

        // Move cursor right, respecting content width and wrap to next line
        if self.cursor_x + 1 < CONTENT_WIDTH {
            self.cursor_x += 1;
        } else if self.cursor_y + 1 < EDITOR_HEIGHT {
            self.cursor_y += 1;
            self.cursor_x = 0;
        } else {
            // At bottom; scroll down if possible
            if self.offset + CONTENT_WIDTH < self.size {
                self.offset += CONTENT_WIDTH;
                self.cursor_x = 0;
            }
        }
    }

    fn delete_char(&mut self) {
        let delete_pos = self.offset + self.cursor_y * CONTENT_WIDTH + self.cursor_x;

        if delete_pos >= self.size {
            return;
        }

        // Shift content left
        for i in delete_pos..(self.size - 1) {
            self.content[i] = self.content[i + 1];
        }

        self.size -= 1;
        self.modified = true;
    }

    fn backspace(&mut self) {
        let delete_pos = self.offset + self.cursor_y * CONTENT_WIDTH + self.cursor_x;

        if delete_pos == 0 {
            return;
        }

        // Shift content left from the previous position
        let start = delete_pos - 1;
        if start < self.size {
            for i in start..(self.size - 1) {
                self.content[i] = self.content[i + 1];
            }
            self.size -= 1;
            self.modified = true;
        }

        // Move cursor left
        if self.cursor_x > 0 {
            self.cursor_x -= 1;
        } else if self.cursor_y > 0 {
            self.cursor_y -= 1;
            self.cursor_x = CONTENT_WIDTH.saturating_sub(1);
        }
    }

    fn handle_input(&mut self) -> bool {
        // Returns false to exit editor
        let scancode = {
            // Poll i8042 status (port 0x64), read scancode from port 0x60
            fn read_scancode() -> u8 {
                loop {
                    let status: u8;
                    unsafe {
                        asm!(
                            "in al, dx",
                            in("dx") 0x64u16,
                            out("al") status,
                            options(nomem, nostack, preserves_flags)
                        );
                    }
                    if status & 1 != 0 {
                        let code: u8;
                        unsafe {
                            asm!(
                                "in al, dx",
                                in("dx") 0x60u16,
                                out("al") code,
                                options(nomem, nostack, preserves_flags)
                            );
                        }
                        if (code & 0x80) == 0 { return code; }
                    }
                }
            }
            read_scancode()
        };

        match scancode {
            // F2 - Save
            0x3C => {
                self.save_file();
                return true;
            }
            // F3 - Quit without save
            0x3D => {
                return false;
            }
            // F4 - Save and quit
            0x3E => {
                self.save_file();
                return false;
            }
            // Q (0x10) with Ctrl
            0x10 => {
                let ctrl = unsafe {
                    let mut c: u8 = 0;
                    asm!("mov al, byte ptr [0x507]", out("al") c);
                    c
                };
                if ctrl != 0 {
                    return false;
                }
                return true;
            }
            // Backspace
            0x0E => {
                self.backspace();
                return true;
            }
            // Delete
            0x53 => {
                self.delete_char();
                return true;
            }
            // Arrow Up
            0x48 => {
                if self.cursor_y > 0 {
                    self.cursor_y -= 1;
                }
                return true;
            }
            // Arrow Down
            0x50 => {
                if self.cursor_y + 1 < EDITOR_HEIGHT {
                    self.cursor_y += 1;
                }
                return true;
            }
            // Arrow Left
            0x4B => {
                if self.cursor_x > 0 {
                    self.cursor_x -= 1;
                } else if self.cursor_y > 0 {
                    self.cursor_y -= 1;
                    self.cursor_x = EDITOR_WIDTH - 6;
                }
                return true;
            }
            // Arrow Right
            0x4D => {
                if self.cursor_x + 1 < CONTENT_WIDTH {
                    self.cursor_x += 1;
                } else if self.cursor_y + 1 < EDITOR_HEIGHT {
                    self.cursor_y += 1;
                    self.cursor_x = 0;
                }
                return true;
            }
            // Home
            0x47 => {
                self.cursor_x = 0;
                self.cursor_y = 0;
                return true;
            }
            // End
            0x4F => {
                self.cursor_y = EDITOR_HEIGHT - 1;
                self.cursor_x = CONTENT_WIDTH.saturating_sub(1);
                return true;
            }
            // Regular character (simple printable ASCII)
            _ => {
                // ASCII codes for printable characters
                if scancode >= 0x02 && scancode <= 0x0D {  // 1-0 and some symbols
                    let ch = match scancode {
                        0x02 => b'1', 0x03 => b'2', 0x04 => b'3', 0x05 => b'4',
                        0x06 => b'5', 0x07 => b'6', 0x08 => b'7', 0x09 => b'8',
                        0x0A => b'9', 0x0B => b'0', 0x0C => b'-', 0x0D => b'=',
                        _ => return true,
                    };
                    self.insert_char(ch);
                } else if scancode >= 0x10 && scancode <= 0x19 {  // QWERTYUIOP
                    let chars = [b'q', b'w', b'e', b'r', b't', b'y', b'u', b'i', b'o', b'p'];
                    self.insert_char(chars[scancode as usize - 0x10]);
                } else if scancode >= 0x1E && scancode <= 0x28 {  // ASDFGHJKL
                    let chars = [b'a', b's', b'd', b'f', b'g', b'h', b'j', b'k', b'l'];
                    self.insert_char(chars[scancode as usize - 0x1E]);
                } else if scancode >= 0x2C && scancode <= 0x32 {  // ZXCVBNM
                    let chars = [b'z', b'x', b'c', b'v', b'b', b'n', b'm'];
                    self.insert_char(chars[scancode as usize - 0x2C]);
                } else if scancode == 0x20 {  // Space
                    self.insert_char(b' ');
                } else if scancode == 0x1C {  // Enter
                    self.insert_char(b'\n');
                }
                return true;
            }
        }
    }

    fn save_file(&mut self) {
        // Save current buffer to FAT16 using 8-char base name
        let mut name8 = [b' '; 8];
        let copy_len = if self.filename_len < 8 { self.filename_len } else { 8 };
        for i in 0..copy_len { name8[i] = self.filename[i]; }
        let data = &self.content[..self.size];
        fat16::fat16_save(&name8, data);
        self.modified = false;
    }
}

pub fn edit_file(filename: &[u8]) {
    let editor = unsafe { &mut *EDITOR.0.get() };
    editor.load_file(filename);

    loop {
        editor.draw_editor();
        if !editor.handle_input() { break; }
    }

    // Return to mini-commander
}
